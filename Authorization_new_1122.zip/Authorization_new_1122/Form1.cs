﻿using DSkin.Forms;
using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace Authorization
{
    public partial class Form1 : DSkinForm
    {
        public Form1()
        {
            InitializeComponent();
        }
        private static byte[] Keys = { 0x12, 0x34, 0x56, 0x78, 0x90, 0xAB, 0xCD, 0xEF };

        public string EncryptDES(string encryptString, string encryptKey)
        {
            try
            {
                byte[] rgbKey = Encoding.UTF8.GetBytes(encryptKey.Substring(0, 8));
                byte[] rgbIV = Keys;
                byte[] inputByteArray = Encoding.UTF8.GetBytes(encryptString);
                DESCryptoServiceProvider dCSP = new DESCryptoServiceProvider();
                MemoryStream mStream = new MemoryStream();
                CryptoStream cStream = new CryptoStream(mStream, dCSP.CreateEncryptor(rgbKey, rgbIV), CryptoStreamMode.Write);
                cStream.Write(inputByteArray, 0, inputByteArray.Length);
                cStream.FlushFinalBlock();
                return Convert.ToBase64String(mStream.ToArray());
            }
            catch
            {
                return encryptString;
            }
        }
        
        private void BtnGenerate_Click_1(object sender, EventArgs e)
        {
            if(TxbSN.Text != "")
            {
                //TxbCode.Text = EncryptDES(TxbSN.Text, "Zhang123");
                TxbCode.Text = EncryptDES(TxbSN.Text, "LGKJ981323");
            }
            else
            {
                DSkinMessageBox.Show("请输入有效的序列号", "生成失败", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }            
        }
    }
}
