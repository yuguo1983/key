﻿namespace Authorization
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.BtnGenerate = new DSkin.Controls.DSkinButton();
            this.dSkinPictureBox2 = new DSkin.Controls.DSkinPictureBox();
            this.dSkinPictureBox1 = new DSkin.Controls.DSkinPictureBox();
            this.TxbCode = new DSkin.Controls.DSkinTextBox();
            this.TxbSN = new DSkin.Controls.DSkinTextBox();
            this.dSkinBaseControl2 = new DSkin.Controls.DSkinBaseControl();
            this.dSkinBaseControl1 = new DSkin.Controls.DSkinBaseControl();
            this.dSkinLabel3 = new DSkin.Controls.DSkinLabel();
            this.dSkinLabel2 = new DSkin.Controls.DSkinLabel();
            this.duiBaseControl1 = new DSkin.DirectUI.DuiBaseControl();
            this.duiBaseControl2 = new DSkin.DirectUI.DuiBaseControl();
            this.dSkinLabel1 = new DSkin.Controls.DSkinLabel();
            this.SuspendLayout();
            // 
            // BtnGenerate
            // 
            this.BtnGenerate.AdaptImage = true;
            this.BtnGenerate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(180)))), ((int)(((byte)(255)))));
            this.BtnGenerate.BaseColor = System.Drawing.Color.Transparent;
            this.BtnGenerate.ButtonBorderWidth = 1;
            this.BtnGenerate.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BtnGenerate.Font = new System.Drawing.Font("微软雅黑", 13F);
            this.BtnGenerate.ForeColor = System.Drawing.Color.White;
            this.BtnGenerate.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.BtnGenerate.HoverImage = null;
            this.BtnGenerate.Location = new System.Drawing.Point(115, 253);
            this.BtnGenerate.Name = "BtnGenerate";
            this.BtnGenerate.NormalImage = null;
            this.BtnGenerate.PressColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.BtnGenerate.PressedImage = null;
            this.BtnGenerate.Radius = 0;
            this.BtnGenerate.ShowButtonBorder = false;
            this.BtnGenerate.Size = new System.Drawing.Size(210, 40);
            this.BtnGenerate.TabIndex = 27;
            this.BtnGenerate.Text = "生  成";
            this.BtnGenerate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.BtnGenerate.TextPadding = 0;
            this.BtnGenerate.Click += new System.EventHandler(this.BtnGenerate_Click_1);
            // 
            // dSkinPictureBox2
            // 
            this.dSkinPictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("dSkinPictureBox2.Image")));
            this.dSkinPictureBox2.Images = new System.Drawing.Image[] {
        ((System.Drawing.Image)(((System.Drawing.Image)(resources.GetObject("dSkinPictureBox2.Images")))))};
            this.dSkinPictureBox2.Location = new System.Drawing.Point(54, 202);
            this.dSkinPictureBox2.Name = "dSkinPictureBox2";
            this.dSkinPictureBox2.Size = new System.Drawing.Size(24, 24);
            this.dSkinPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.dSkinPictureBox2.TabIndex = 36;
            this.dSkinPictureBox2.Text = "dSkinPictureBox2";
            // 
            // dSkinPictureBox1
            // 
            this.dSkinPictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("dSkinPictureBox1.Image")));
            this.dSkinPictureBox1.Images = new System.Drawing.Image[] {
        ((System.Drawing.Image)(((System.Drawing.Image)(resources.GetObject("dSkinPictureBox1.Images")))))};
            this.dSkinPictureBox1.Location = new System.Drawing.Point(54, 128);
            this.dSkinPictureBox1.Name = "dSkinPictureBox1";
            this.dSkinPictureBox1.Size = new System.Drawing.Size(21, 24);
            this.dSkinPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.dSkinPictureBox1.TabIndex = 35;
            this.dSkinPictureBox1.Text = "dSkinPictureBox1";
            // 
            // TxbCode
            // 
            this.TxbCode.BitmapCache = false;
            this.TxbCode.BorderColor = System.Drawing.Color.Transparent;
            this.TxbCode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxbCode.FocusedBorderColor = System.Drawing.Color.Transparent;
            this.TxbCode.Font = new System.Drawing.Font("微软雅黑", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TxbCode.HoverBorderColor = System.Drawing.Color.Transparent;
            this.TxbCode.Location = new System.Drawing.Point(90, 204);
            this.TxbCode.Name = "TxbCode";
            this.TxbCode.ReadOnly = true;
            this.TxbCode.Size = new System.Drawing.Size(300, 22);
            this.TxbCode.TabIndex = 38;
            this.TxbCode.TransparencyKey = System.Drawing.Color.Empty;
            this.TxbCode.WaterFont = new System.Drawing.Font("微软雅黑", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TxbCode.WaterText = "生成的授权码";
            this.TxbCode.WaterTextOffset = new System.Drawing.Point(0, 0);
            // 
            // TxbSN
            // 
            this.TxbSN.BitmapCache = false;
            this.TxbSN.BorderColor = System.Drawing.Color.Transparent;
            this.TxbSN.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxbSN.FocusedBorderColor = System.Drawing.Color.Transparent;
            this.TxbSN.Font = new System.Drawing.Font("微软雅黑", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TxbSN.HoverBorderColor = System.Drawing.Color.Transparent;
            this.TxbSN.Location = new System.Drawing.Point(90, 131);
            this.TxbSN.Name = "TxbSN";
            this.TxbSN.Size = new System.Drawing.Size(300, 22);
            this.TxbSN.TabIndex = 37;
            this.TxbSN.TransparencyKey = System.Drawing.Color.Empty;
            this.TxbSN.WaterFont = new System.Drawing.Font("微软雅黑", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TxbSN.WaterText = "输入序列号";
            this.TxbSN.WaterTextOffset = new System.Drawing.Point(0, 0);
            // 
            // dSkinBaseControl2
            // 
            this.dSkinBaseControl2.Borders.AllColor = System.Drawing.Color.Silver;
            this.dSkinBaseControl2.Borders.BottomColor = System.Drawing.Color.Silver;
            this.dSkinBaseControl2.Borders.LeftColor = System.Drawing.Color.Silver;
            this.dSkinBaseControl2.Borders.RightColor = System.Drawing.Color.Silver;
            this.dSkinBaseControl2.Borders.TopColor = System.Drawing.Color.Silver;
            this.dSkinBaseControl2.Location = new System.Drawing.Point(44, 193);
            this.dSkinBaseControl2.Name = "dSkinBaseControl2";
            this.dSkinBaseControl2.Size = new System.Drawing.Size(355, 40);
            this.dSkinBaseControl2.TabIndex = 34;
            this.dSkinBaseControl2.Text = "dSkinBaseControl2";
            // 
            // dSkinBaseControl1
            // 
            this.dSkinBaseControl1.Borders.AllColor = System.Drawing.Color.Silver;
            this.dSkinBaseControl1.Borders.BottomColor = System.Drawing.Color.Silver;
            this.dSkinBaseControl1.Borders.LeftColor = System.Drawing.Color.Silver;
            this.dSkinBaseControl1.Borders.RightColor = System.Drawing.Color.Silver;
            this.dSkinBaseControl1.Borders.TopColor = System.Drawing.Color.Silver;
            this.dSkinBaseControl1.Location = new System.Drawing.Point(44, 120);
            this.dSkinBaseControl1.Name = "dSkinBaseControl1";
            this.dSkinBaseControl1.Size = new System.Drawing.Size(355, 40);
            this.dSkinBaseControl1.TabIndex = 33;
            this.dSkinBaseControl1.Text = "dSkinBaseControl1";
            // 
            // dSkinLabel3
            // 
            this.dSkinLabel3.Font = new System.Drawing.Font("微软雅黑", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.dSkinLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.dSkinLabel3.Location = new System.Drawing.Point(44, 172);
            this.dSkinLabel3.Name = "dSkinLabel3";
            this.dSkinLabel3.Size = new System.Drawing.Size(56, 24);
            this.dSkinLabel3.TabIndex = 32;
            this.dSkinLabel3.Text = "授权码";
            // 
            // dSkinLabel2
            // 
            this.dSkinLabel2.Font = new System.Drawing.Font("微软雅黑", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.dSkinLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.dSkinLabel2.Location = new System.Drawing.Point(43, 98);
            this.dSkinLabel2.Name = "dSkinLabel2";
            this.dSkinLabel2.Size = new System.Drawing.Size(56, 24);
            this.dSkinLabel2.TabIndex = 31;
            this.dSkinLabel2.Text = "序列号";
            // 
            // duiBaseControl1
            // 
            this.duiBaseControl1.AutoSize = false;
            this.duiBaseControl1.BackColor = System.Drawing.Color.LightSalmon;
            this.duiBaseControl1.DesignModeCanMove = false;
            this.duiBaseControl1.DesignModeCanResize = false;
            this.duiBaseControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.duiBaseControl1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.duiBaseControl1.Location = new System.Drawing.Point(0, 0);
            this.duiBaseControl1.Name = "duiBaseControl1";
            this.duiBaseControl1.Size = new System.Drawing.Size(440, 5);
            this.duiBaseControl1.Virtualization = true;
            // 
            // duiBaseControl2
            // 
            this.duiBaseControl2.AutoSize = false;
            this.duiBaseControl2.BackColor = System.Drawing.Color.ForestGreen;
            this.duiBaseControl2.DesignModeCanMove = false;
            this.duiBaseControl2.DesignModeCanResize = false;
            this.duiBaseControl2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.duiBaseControl2.Location = new System.Drawing.Point(0, 5);
            this.duiBaseControl2.Name = "duiBaseControl2";
            this.duiBaseControl2.Size = new System.Drawing.Size(440, 75);
            this.duiBaseControl2.Virtualization = true;
            // 
            // dSkinLabel1
            // 
            this.dSkinLabel1.Font = new System.Drawing.Font("微软雅黑", 20F);
            this.dSkinLabel1.ForeColor = System.Drawing.Color.White;
            this.dSkinLabel1.Location = new System.Drawing.Point(17, 22);
            this.dSkinLabel1.Name = "dSkinLabel1";
            this.dSkinLabel1.Size = new System.Drawing.Size(183, 49);
            this.dSkinLabel1.TabIndex = 39;
            this.dSkinLabel1.Text = "授权码生成";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.CanResize = false;
            this.CaptionShowMode = DSkin.TextShowModes.None;
            this.ClientSize = new System.Drawing.Size(440, 320);
            this.CloseBox.HoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.CloseBox.NormalColor = System.Drawing.Color.White;
            this.Controls.Add(this.dSkinLabel1);
            this.Controls.Add(this.dSkinPictureBox2);
            this.Controls.Add(this.dSkinPictureBox1);
            this.Controls.Add(this.TxbCode);
            this.Controls.Add(this.TxbSN);
            this.Controls.Add(this.dSkinBaseControl2);
            this.Controls.Add(this.dSkinBaseControl1);
            this.Controls.Add(this.dSkinLabel3);
            this.Controls.Add(this.dSkinLabel2);
            this.Controls.Add(this.BtnGenerate);
            this.DoubleClickMaximized = false;
            this.DragChangeBackImage = false;
            this.DUIControls.Add(this.duiBaseControl1);
            this.DUIControls.Add(this.duiBaseControl2);
            this.EnableAnimation = false;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsLayeredWindowForm = false;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.ShowShadow = true;
            this.SystemButtonsOffset = new System.Drawing.Point(10, 28);
            this.Text = "授权码生成";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DSkin.Controls.DSkinButton BtnGenerate;
        private DSkin.Controls.DSkinPictureBox dSkinPictureBox2;
        private DSkin.Controls.DSkinPictureBox dSkinPictureBox1;
        private DSkin.Controls.DSkinTextBox TxbCode;
        private DSkin.Controls.DSkinTextBox TxbSN;
        private DSkin.Controls.DSkinBaseControl dSkinBaseControl2;
        private DSkin.Controls.DSkinBaseControl dSkinBaseControl1;
        private DSkin.Controls.DSkinLabel dSkinLabel3;
        private DSkin.Controls.DSkinLabel dSkinLabel2;
        private DSkin.DirectUI.DuiBaseControl duiBaseControl1;
        private DSkin.DirectUI.DuiBaseControl duiBaseControl2;
        private DSkin.Controls.DSkinLabel dSkinLabel1;
    }
}

